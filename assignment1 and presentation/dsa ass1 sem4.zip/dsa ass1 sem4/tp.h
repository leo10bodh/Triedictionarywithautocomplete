typedef struct node{
    int data;
    struct node* left;
    struct node* right;
    struct node* parent;
    char *name;
}node;
typedef node* BST;

void init_BST(BST* root);
node* insert(BST root,int key,char*,node* parent );
node* search(BST root,int key);
node* destroy_tree(BST root);
node* find_successor(node* root);
node* remove_node(node* root,int key);
void printlevel(node *root,int level);
void postOrderIterative(node* root);

struct Stack
{
    int size;
    int top;
    struct node* *array;
};
struct Stack* createStack(int size);
int isFull(struct Stack* stack);
int isEmpty(struct Stack* stack);
void push(struct Stack* stack, node* n);
struct node* pop(struct Stack* stack);
struct node* peek(struct Stack* stack);




