#include<stdio.h>
#include<malloc.h>
#include "stack.c"


void init_BST(BST* root)
{
    *root=NULL;
}
node* insert(BST root,int key,char *name,node* parent)
{
    if(root==NULL){
    node* nn=(node*)malloc(sizeof(node));
    nn->data=key;
    nn->name=name;
    nn->left=NULL;
    nn->right=NULL;
    nn->parent=parent;
    return nn;
}
    if(root->data==key)
    {
        return root;
    }
    else if(root->data >key)
    {
        root->left=insert(root->left,key,name,root);
    }
    else
    {
        root->right=insert(root->right,key,name,root);
    }
    return root;
}
node* search(BST root,int key)
{
    if(root==NULL){

    printf("element not found");
    return NULL;
}
    if(root->data==key)
    {
        printf("element found");
        return root;
    }
    else if(root->data >key)
    {
        root->left=search(root->left,key);
        return root;
    }
    else
    {
        root->right=search(root->right,key);
        return root;
    }
}
node* destroy_tree(BST root)
{
    if(root==NULL){

    printf("already destroyed");
    return NULL;
    }
    else{
        root->left=NULL;
        root->right=NULL;
        free(root);
        printf("tree destroyed");
        return NULL;

    }
}

node* find_successor(node* root)
{
    while(root->left){
        root=root->left;
    }
    return root;
}
node* remove_node(node* root,int key){
    if(root==NULL)
    {
        return NULL;
    }
    if(root->data==key)
    {
        if(root->left==NULL && root->right==NULL){
            free(root);
            return NULL;
        }
        else if(root->left==NULL || root->right==NULL)
        {
            if(root->left!=NULL)
            {
                node* temp=root->left;
                temp->parent=root->parent;
                free(root);
                return temp;
            }
            else{
                node* temp=root->right;
                temp->parent=root->parent;
                free(root);
                return temp;
            }
    }
        else{
            node* successor=find_successor(root->right);
            root->data=successor->data;
            root->right=remove_node(root->right,successor->data);
            return root;
        }
    }
    else if(root->data < key){
        root->right=remove_node(root->right,key);
    }
    else{
        root->left=remove_node(root->left,key);
    }
    return root;
}


/*node* find_successor(node* root){
    while(root->left) root=root->left;
    return root;
}
node* remove_node(node* root,int key){
    if(root==NULL) return NULL;
    if(root->data==key){
        if(root->left==NULL && root->right==NULL){
            free(root);
            return NULL;
        }
        else if(root->left==NULL || root->right==NULL){
            if(root->left!=NULL){
                node* temp=root->left;
                free(root);
                return temp;
            }
            else{
                node* temp=root->right;
                free(root);
                return temp;
            }
        }
        else{
            node* successor=find_successor(root->right);
            root->data=successor->data;
            root->right=remove_node(root->right,successor->data);
            return root;
        }
    }
    else if(root->data<key){
        root->right=remove_node(root->right,key);
    }
    else root->left=remove_node(root->left,key);
    return root;
}*/
void inorder(node* root){
    if(root==NULL) return;
    inorder(root->left);
    printf("%d ",root->data);
    inorder(root->right);
}
void printlevel(node *root,int level)
{
    if(root==NULL)
        return;
    if(level==1)
        printf("%d\n%s",root->data,root->name);
    if(level>1){
        printlevel(root->left,level-1);
        printlevel(root->right,level-1);
    }
}
void postOrderIterative(node* root)
{
    // Check for empty tree
    if (root == NULL)
        return;

    struct Stack* stack = createStack(100);
    do
    {
        // Move to leftmost node
        while (root)
        {
            // Push root's right child and then root to stack.
            if (root->right)
                push(stack, root->right);
            push(stack, root);

            // Set root as root's left child
            root = root->left;
        }

        // Pop an item from stack and set it as root
        root = pop(stack);

        // If the popped item has a right child and the right child is not
        // processed yet, then make sure right child is processed before root
        if (root->right && peek(stack) == root->right)
        {
            pop(stack); // remove right child from stack
            push(stack, root); // push root back to stack
            root = root->right; // change root so that the right
                                // child is processed next
        }
        else // Else print root's data and set root as NULL
        {
            printf("%d %s \n", root->data,root->name);
            //if(root->parent)
            //    printf("Parent node of %d : %d - %s\n",root->key,root->parent->key,root->parent->name);
            //else
            //    printf("Parent Node does not exists\n");
            root = NULL;
        }
    } while (!isEmpty(stack));
}

