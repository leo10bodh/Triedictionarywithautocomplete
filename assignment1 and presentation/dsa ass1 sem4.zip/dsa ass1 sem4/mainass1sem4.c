#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include "tp.c"



int main()
{
    //BST root;
    /*init_BST(&root);
    root=insert(root,34);
    root=insert(root,3);
    root=insert(root,4);
    root=insert(root,334);
    root=insert(root,364);
    inorder(root);
    root=search(root,364);
    //root=destroy_tree(root);
    inorder(root);
    root=remove_node(root,34);
    inorder(root);
    printf("\n");
    printf("Level by level traversal : ");
    printlevel(root,3);
    */
    int a;


    while(a!=7){
    printf("enter 1 to initialize the tree\n");
    printf("enter 2 to insert\n");
    printf("enter 3 delete\n");
    printf("enter 4 to search\n");
    printf("enter 5 to display level\n");
    printf("enter 6 to destroy tree\n");
    printf("enter 7 to stop\n");
    printf("enter 8 to traverse the tree in postorder\n");
    printf("enter a choice\n");
    BST root;
    scanf("%d",&a);
    if(a==1)
    {

        init_BST(&root);
    }

    else if(a==2)
    {
        int b;
        char *n = (char *)malloc(100*sizeof(char));
        printf("enter the number to insert\n");
        scanf("%d",&b);
        char ch;
        scanf("%c",&ch);
        printf("enter your name : ");
        fgets(n,100,stdin);

        root=insert(root,b,n,NULL);
    }
    else if(a==3)
    {
        int b;
        printf("enter the number to delete");
        scanf("%d",&b);
        root=remove_node(root,b);
    }
     else if(a==4)
    {
        int b;
        printf("enter the number to search\n");
        scanf("%d",&b);
        root=search(root,b);
    }
     else if(a==5)
    {
        int b;
        printf("enter the level for that level elements\n");
        scanf("%d",&b);
        printlevel(root,b);
    }
     else if(a==6)
    {
        root=destroy_tree(root);

    }
    else if (a==8){
        printf("postorder traversal : ");
        postOrderIterative(root);
    }
    else
    {
        printf("enter again\n");
    }
}



    return 0;
}



